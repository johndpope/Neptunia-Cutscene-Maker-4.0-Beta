#pragma once

#define WINVER			0x0501
#define _WIN32_IE		0x0501
#define _WIN32_WINNT	0x0501

#include <windows.h>
#include <shlobj.h>
#include <shlwapi.h>

#define IS_UPPER(c) \
	(((SIZE_T)(c) - 'A') <= 'Z'-'A')

#define TO_LOWER(c) \
	(IS_UPPER(c) ? (c) + ('a'-'A') : (c))

__forceinline BOOL IsProcessorSupportedSSE2(
	void)
{
	#define CPU_SUPPORT_CMOV	(1 << 15)
	#define CPU_SUPPORT_MMX		(1 << 23)
	#define CPU_SUPPORT_SSE		(1 << 25)
	#define CPU_SUPPORT_SSE2	(1 << 26)
	#define CPU_CHECK_BITS		(CPU_SUPPORT_CMOV | CPU_SUPPORT_MMX | CPU_SUPPORT_SSE | CPU_SUPPORT_SSE2)

	__asm
	{
		push    ebx

		pushfd					; push original EFLAGS
		pop     eax				; get original EFLAGS
		mov     ecx, eax		; save original EFLAGS
		xor     eax, 0200000h	; flip AC bit in EFLAGS
		push    eax				; save new EFLAGS value on stack
		popfd					; replace current EFLAGS value
		pushfd					; get new EFLAGS
		pop     eax				; store new EFLAGS in EAX
		xor     eax, ecx		; can't toggle AC bit
		je      $end_cpu_type

		xor     eax, eax
		cpuid

		test    eax, eax		; make sure 1 is valid input for CPUID
		jz      $end_cpu_type	; if not, jump to end

		mov     eax, 1
		cpuid
		xor     eax, eax
		and     edx, CPU_CHECK_BITS
		cmp     edx, CPU_CHECK_BITS
		sete    al

$end_cpu_type:
		pop     ebx
	}
}

__forceinline BOOL IsAboveWinXP(
	void)
{
#pragma warning(disable:4996)

	if (!(GetVersion() & 0x80000000)) // NT?
	{
		OSVERSIONINFOA ov;

		ov.dwOSVersionInfoSize = sizeof(OSVERSIONINFOA);
		GetVersionExA(&ov);
		if (ov.dwMajorVersion == 5)
			return ov.dwMinorVersion; // 0: Win2000, 1: WinXP

		return ov.dwMajorVersion >= 6;
	}
	return FALSE;
}

__forceinline LPVOID MemAlloc(
	DWORD uSize)
{
	return HeapAlloc(
		GetProcessHeap(),
		HEAP_ZERO_MEMORY | HEAP_GENERATE_EXCEPTIONS,
		uSize);
}

__forceinline void MemFree(
	LPVOID lpBuf)
{
	HeapFree(
		GetProcessHeap(),
		0,
		lpBuf);
}

typedef struct _FILEMAP
{
	HANDLE hFile;
	HANDLE hMap;
	BYTE *lpFileBuf;
	DWORD uSize;
} FILEMAP;

BOOL NR2_OpenFileMap(FILEMAP *, LPCSTR, DWORD);
void NR2_CloseFileMap(FILEMAP *);

void __cdecl NR2_ErrorMsg(const char *, ...);
void __cdecl NR2_Printf(const char *, ...);
BOOL NR2_ExtensionFilter(LPCWSTR, LPCSTR);
BOOL NR2_CreateDirectory(LPCSTR);
BOOL NR2_PutFile(LPCSTR, void *, DWORD);
BOOL NR2_UnpackFile(LPCSTR, void *, DWORD);
void __fastcall NR2_Uncompress(void *, BYTE *);
