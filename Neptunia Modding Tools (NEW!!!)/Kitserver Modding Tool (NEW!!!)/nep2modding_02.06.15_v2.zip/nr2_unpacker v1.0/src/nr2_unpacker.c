#include <nr2_unpacker.h>

#define NR2_APPVERSION		"v1.0"
#define NR2_APPTITLE		"Hyperdimension Neptunia Re;Birth2 Unpacker " NR2_APPVERSION
#define NR2_MAXTEXT			1024

#define NR2_DWTABLELEN		256
#define NR2_DWHINTBITS		10	// 8 ~ 15

/*
* PAC file
*/
typedef struct _DW_PACHEADER
{
	BYTE magic[8];			// "DW_PACK\0"
	DWORD file_pos;			// 0
	DWORD file_cnt;
	DWORD status;			// 0
} DW_PACHEADER;

typedef struct _DW_PACFILE
{
	DWORD a;
	WORD file_index;
	WORD b;
	BYTE path[264];
	DWORD pack_size;
	DWORD unpack_size;
	DWORD packed_flag;
	DWORD file_offset;
} DW_PACFILE;

typedef struct _DW_PACINFO
{
	DWORD unpack_size;
	DWORD pack_size;
	DWORD data_offset;
} DW_PACINFO;

typedef struct _DW_PACDATA
{
	DWORD magic;			// 0x1234
	DWORD pack_cnt;
	DWORD file_type;
	DWORD hdr_offset;
	DW_PACINFO info[/* ANYSIZE_ARRAY */];
} DW_PACDATA;

/*
* app
*/
static HANDLE __appstd;


#ifdef _DEBUG
int APIENTRY WinMain(
	HINSTANCE hInst,
	HINSTANCE hPrevInst,
	LPSTR pCmdLine,
	int nCmdShow)
#else
void __cdecl WinEntry(
	void)
#endif
{
	HANDLE hFile = INVALID_HANDLE_VALUE;
	DW_PACHEADER hdr[1];
	DW_PACFILE *pf = NULL;
	DW_PACDATA *src_buf = NULL;
	DWORD pf_len = 0;
	DWORD src_len = 0;
	WCHAR **argv;
	int argc;
	WCHAR *filterW;
	DWORD size, offset;
	DWORD i, j, ret;
	char *fpath, *ext;
	char path[NR2_MAXTEXT];
	char temp[NR2_MAXTEXT];

	if (!IsProcessorSupportedSSE2())
		ExitProcess(ERROR_INSTALL_PLATFORM_UNSUPPORTED);

	if (!IsAboveWinXP())
		ExitProcess(ERROR_OLD_WIN_VERSION);

	argv = CommandLineToArgvW(GetCommandLineW(), &argc);
	if (argc <= 1)
	{
	ErrShowHelp:
		NR2_ErrorMsg(
			"Usage:\n"
			"nr2_unpacker <input.pac> <type mask...>\n"
			"\n"
			"<input.pac>\tHyperdimension Neptunia Re;Birth2 PAC file.\n"
			"<type mask>\tAppend extension to the filter.\n"
			"\n"
			"Example:\n"
			"nr2_unpacker c:\\SYSTEM00000.pac\n"
			"nr2_unpacker c:\\SYSTEM00000.pac *.tid\n"
			"nr2_unpacker c:\\SYSTEM00000.pac *.gstr;*.gbin;*.ffu");
		goto ErrExit;
	}

	AllocConsole();
	__appstd = GetStdHandle(STD_OUTPUT_HANDLE);

	NR2_Printf(NR2_APPTITLE "\n");

	for (i = 1; i < (unsigned int)argc; ++i)
	{
		WideCharToMultiByte(CP_ACP, 0, argv[i], -1, path, NR2_MAXTEXT, NULL, NULL);
		NR2_Printf("Input File: %s", path);

		ext = PathFindExtension(path);
		if (lstrcmpi(ext, ".pac"))
			goto ErrShowHelp;

		hFile = CreateFile(
			path,
			GENERIC_READ,
			FILE_SHARE_READ,
			0,
			OPEN_EXISTING,
			FILE_ATTRIBUTE_NORMAL,
			NULL);
		if (hFile == INVALID_HANDLE_VALUE)
		{
			NR2_ErrorMsg("ERROR: Failed to open file.");
			goto ErrExit;
		}

		if (!ReadFile(hFile, hdr, sizeof(DW_PACHEADER), &ret, NULL))
		{
			NR2_ErrorMsg("ERROR: Failed to read file.");
			goto ErrExit;
		}

		if (memcmp(hdr->magic, "DW_PACK", sizeof("DW_PACK")))
		{
			NR2_ErrorMsg("ERROR: Unsupported file format.");
			goto ErrExit;
		}

		size = sizeof(DW_PACFILE) * hdr->file_cnt;
		offset = size + sizeof(DW_PACHEADER);
		if (pf_len < size)
		{
			MemFree(pf);
			pf = MemAlloc(size);
			pf_len = size;
		}

		if (!ReadFile(hFile, pf, size, &ret, NULL))
		{
			NR2_ErrorMsg("ERROR: Failed to read file.");
			goto ErrExit;
		}

		PathRemoveExtension(path);
		PathAddBackslash(path);
		fpath = path + lstrlen(path);

		filterW = ((i + 1) < (unsigned int)argc && *argv[i + 1] == '*') ? argv[++i] : NULL;
		for (j = 0; j < hdr->file_cnt; ++j)
		{
			if (!pf[j].pack_size || !pf[j].unpack_size)
				continue;

			if (filterW && !NR2_ExtensionFilter(filterW, pf[j].path))
				continue;

			NR2_Printf("%u/%u: %s", j + 1, hdr->file_cnt, pf[j].path);

			if (SetFilePointer(hFile, offset + pf[j].file_offset, 0, FILE_BEGIN) == INVALID_SET_FILE_POINTER)
			{
				NR2_ErrorMsg("ERROR: Failed to seek file.");
				goto ErrExit;
			}

			if (src_len < pf[j].pack_size + 2)
			{
				MemFree(src_buf);
				src_buf = MemAlloc(pf[j].pack_size + 2);
				src_len = pf[j].pack_size;
			}

			if (!ReadFile(hFile, src_buf, pf[j].pack_size, &ret, NULL))
			{
				NR2_ErrorMsg("ERROR: Failed to read file.");
				goto ErrExit;
			}

			lstrcpy(fpath, pf[j].path);
			lstrcpy(temp, path);
			*PathFindFileName(temp) = '\0';
			PathRemoveBackslash(temp);
			if (!NR2_CreateDirectory(temp))
			{
				NR2_ErrorMsg("ERROR: Failed to create directory.");
				goto ErrExit;
			}

			if (pf[j].packed_flag == 1)
			{
				if (!NR2_UnpackFile(path, src_buf, pf[j].pack_size))
					goto ErrExit;
			}
			else
			{
				if (!NR2_PutFile(path, src_buf, pf[j].pack_size))
					goto ErrExit;
			}
		}

		NR2_Printf("Done.\n");
		CloseHandle(hFile);
		hFile = INVALID_HANDLE_VALUE;
	}

ErrExit:
	FreeConsole();
	if (hFile != INVALID_HANDLE_VALUE)
		CloseHandle(hFile);
	GlobalFree(argv);
	MemFree(pf);
	MemFree(src_buf);
#ifdef _DEBUG
	return ERROR_SUCCESS;
#else
	ExitProcess(ERROR_SUCCESS);
#endif
}

void __cdecl NR2_ErrorMsg(
	const char *fmt, ...)
{
	char str[NR2_MAXTEXT];
	va_list arg;

	va_start(arg, fmt);
	wvnsprintf(str, NR2_MAXTEXT, fmt, arg);
	va_end(arg);
	MessageBox(GetConsoleWindow(), str, NR2_APPTITLE, MB_ICONWARNING);
}

void __cdecl NR2_Printf(
	const char *fmt, ...)
{
	char str[NR2_MAXTEXT];
	va_list arg;
	int len;

	va_start(arg, fmt);
	len = wvnsprintf(str, NR2_MAXTEXT - 1, fmt, arg);
	va_end(arg);
	str[len] = '\n';
	WriteFile(__appstd, str, len + 1, NULL, NULL);
}

BOOL NR2_ExtensionFilter(
	LPCWSTR filterW,
	LPCSTR path)
{
	const WORD *p = filterW;
	const BYTE *s, *ext;

	ext = PathFindExtension(path);
	while (*p == '*')
	{
		if (*(p + 1) == '.' && *(p + 2) == '*')
			return TRUE; // *.*

		s = ext;
		p = p + 1;

		while (1)
		{
			DWORD c1 = *p++;
			DWORD c2 = *s++;

			if (!c1)
				return !c2;

			if (c1 == ';')
			{
				if (!c2)
					return TRUE;
				break;
			}
			else if (TO_LOWER(c1) != TO_LOWER(c2))
			{
				while ((c1 = *p++) != ';')
				{
					if (!c1)
						return FALSE;
				}
				break;
			}
		}
	}
	return FALSE;
}

BOOL NR2_CreateDirectory(
	LPCSTR lpszPath)
{
	DWORD attr;
	WCHAR path[NR2_MAXTEXT];

	attr = GetFileAttributes(lpszPath);
	if (attr != INVALID_FILE_ATTRIBUTES)
		return attr & FILE_ATTRIBUTE_DIRECTORY;

	MultiByteToWideChar(CP_ACP, 0, lpszPath, -1, path, NR2_MAXTEXT);
	return !SHCreateDirectory(NULL, path);
}

BOOL NR2_OpenFileMap(
	FILEMAP *map,
	LPCSTR path,
	DWORD size)
{
	map->hFile = CreateFile(
		path,
		GENERIC_WRITE | GENERIC_READ,
		0,
		0,
		CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL,
		NULL);
	map->hMap = NULL;
	map->lpFileBuf = NULL;
	if (map->hFile == INVALID_HANDLE_VALUE)
		map->hFile = NULL;
	else
	{
		map->hMap = CreateFileMapping(map->hFile, NULL, PAGE_READWRITE, 0, size, NULL);
		if (map->hMap)
		{
			map->lpFileBuf = MapViewOfFile(map->hMap, FILE_MAP_WRITE, 0, 0, size);
			if (map->lpFileBuf)
				return TRUE;
		}
	}

	NR2_CloseFileMap(map);
	return FALSE;
}

void NR2_CloseFileMap(
	FILEMAP *map)
{
	if (map->lpFileBuf)
		UnmapViewOfFile(map->lpFileBuf);
	if (map->hMap)
		CloseHandle(map->hMap);
	if (map->hFile)
		CloseHandle(map->hFile);
}

BOOL NR2_PutFile(
	LPCSTR path,
	void *data,
	DWORD size)
{
	FILEMAP map[1];

	if (!NR2_OpenFileMap(map, path, size))
	{
		NR2_ErrorMsg("ERROR: Failed to write file.");
		return FALSE;
	}

	__movsb(map->lpFileBuf, data, size);
	NR2_CloseFileMap(map);
	return TRUE;
}

BOOL NR2_UnpackFile(
	LPCSTR path,
	DW_PACDATA *data,
	DWORD pack_size)
{
	FILEMAP map[1];
	DWORD offset;
	DWORD total;
	DWORD i;

	if (pack_size < sizeof(DW_PACDATA))
	{
		NR2_ErrorMsg("ERROR: Invalid file size.");
		return FALSE;
	}

	if (data->magic != 0x1234)
	{
		NR2_ErrorMsg("ERROR: Bad magic code.");
		return FALSE;
	}

	if (!data->pack_cnt)
		return TRUE;

	total = 0;
	for (i = 0; i < data->pack_cnt; ++i)
	{
		total += data->info[i].unpack_size;
		offset = data->hdr_offset + data->info[i].pack_size + data->info[i].data_offset;
		if (!data->info[i].pack_size || !data->info[i].unpack_size || offset > pack_size)
		{
			NR2_ErrorMsg("ERROR: Corrupt data header found.");
			return FALSE;
		}
	}

	if (!NR2_OpenFileMap(map, path, total))
	{
		NR2_ErrorMsg("ERROR: Failed to write file.");
		return FALSE;
	}

	NR2_Uncompress(data, map->lpFileBuf);
	NR2_CloseFileMap(map);
	return TRUE;
}

#if 1
static WORD pak_dic[NR2_DWTABLELEN * 2];
static WORD pak_hint[1 << NR2_DWHINTBITS][2];

__declspec(naked) DWORD NR2_MakeDictionary(
	DWORD pak_tlen /* ebx */,
	DWORD pak_m /* ecx */,
	DWORD pak_k /* edx */,
	BYTE *pak_src /* esi */)
{
	__asm
	{
		cmp       ecx, 8
		ja        $unpacker_test_hbit

		movzx     eax, word ptr [esi]
		bswap     eax
		shld      edx, eax, 16
		add       ecx, 16
		add       esi, 2

$unpacker_test_hbit:
		dec       ecx
		bt        edx, ecx
		jc        $unpacker_mode_dic

		mov       eax, edx
		sub       ecx, 8
		shr       eax, cl
		and       eax, 255
		ret

$unpacker_mode_dic:
		push      edi
		mov       edi, ebx
		inc       ebx
		call      NR2_MakeDictionary
		mov       [pak_dic+edi*4-1024], ax
		call      NR2_MakeDictionary
		mov       [pak_dic+edi*4-1024+2], ax
		mov       eax, edi
		pop       edi
		ret
	}
}

__declspec(naked) DWORD NR2_MakeHintTable(
	void)
{
	__asm
	{
		push      ecx
		push      edx

		xor       edx, edx
$unpacker_make_hint_t_rep:
		mov       eax, 256
		mov       ecx, NR2_DWHINTBITS
$unpacker_search_ch_rep:
		dec       ecx
		lea       eax, [pak_dic+eax*4-1024]
		mov       ebx, edx
		shr       ebx, cl
		and       ebx, 1
		movzx     eax, word ptr [eax+ebx*2]
		cmp       eax, 255
		jbe       $unpacker_hint_limit
		test      ecx, ecx
		jnz       $unpacker_search_ch_rep

$unpacker_hint_limit:
		mov       ebx, 1
		shl       ebx, cl
		shl       ecx, 16
		sub       ebx, 1
		or        eax, ecx
		or        ebx, edx
$unpacker_put_hint_rep:
		mov       [pak_hint+edx*4], eax
		inc       edx
		cmp       edx, ebx
		jbe       $unpacker_put_hint_rep
		cmp       edx, 1<<NR2_DWHINTBITS
		jb        $unpacker_make_hint_t_rep

		pop       edx
		pop       ecx
		ret
	}
}

__declspec(naked) void __fastcall NR2_Uncompress(
	DW_PACDATA *data,
	BYTE *buf)
{
	__asm
	{
		push      edi
		push      esi
		push      ebx
		push      ebp

		sub       esp, 12
		mov       ebp, ecx
		mov       edi, edx

		mov       eax, [ebp+12] ; hdr_offset
		mov       ecx, [ebp+4] ; pack_cnt
		lea       eax, [eax+ebp]
		lea       ecx, [ecx+ecx*2]
   		lea       ecx, [ecx*4+ebp]
		mov       [esp+8], eax ; src
		mov       [esp+4], ecx ; info_max

$unpacker_core_rep:
		mov       edx, [ebp+16] ; unpack_size
		lea       edx, [edi+edx]
		mov       ebx, 256
		mov       esi, [esp+8] ; src
		add       esi, [ebp+24] ; data_offset
		mov       [esp], edx ; dst_max
		xor       ecx, ecx
		call      NR2_MakeDictionary

		cmp       eax, 255
		ja        $unpacker_make_hint_tbl

		mov       ecx, [ebp+16] ; unpack_size
		rep       stosb
		jmp       $unpacker_next_loop

$unpacker_make_hint_tbl:
		call      NR2_MakeHintTable

$unpacker_decode_rep:
		cmp       ecx, NR2_DWHINTBITS
		jae       $unpacker_test_hint_bits

		movzx     eax, word ptr [esi]
		bswap     eax
		shld      edx, eax, 16
		add       ecx, 16
		add       esi, 2

$unpacker_test_hint_bits:
		mov       eax, edx
		sub       ecx, NR2_DWHINTBITS
		shr       eax, cl
		and       eax, (1<<NR2_DWHINTBITS)-1
		mov       ebx, [pak_hint+eax*4]
		movzx     eax, bx
		shr       ebx, 16
		cmp       eax, 255
		lea       ecx, [ecx+ebx]
		jbe       $unpacker_put_ch

$unpacker_search_ch_rep:
		dec       ecx
		lea       eax, [pak_dic+eax*4-1024]
		jns       $unpacker_test_hbit

		movzx     edx, word ptr [esi]
		bswap     edx
		shr       edx, 16
		mov       ecx, 15
		add       esi, 2

$unpacker_test_hbit:
		mov       ebx, edx
		shr       ebx, cl
		and       ebx, 1
		movzx     eax, word ptr [eax+ebx*2]
		cmp       eax, 255
		ja        $unpacker_search_ch_rep

$unpacker_put_ch:
		mov       [edi], al
		inc       edi
		cmp       edi, [esp] ; dst_max
		jb        $unpacker_decode_rep

$unpacker_next_loop:
		add       ebp, 12
		cmp       ebp, [esp+4] ; info_max
		jb        $unpacker_core_rep

		add       esp, 12
		pop       ebp
		pop       ebx
		pop       esi
		pop       edi
		ret
	}
}

#else
typedef struct _UNPACKER
{
	const BYTE *src;
	DWORD k;
	DWORD m;
	DWORD tlen;
	DWORD dic[2][NR2_DWTABLELEN];
	DWORD hint[1 << NR2_DWHINTBITS];
	DWORD bits[1 << NR2_DWHINTBITS];
} UNPACKER;

int NR2_MakeDictionary(
	UNPACKER *pak)
{
	int r;

	if (!pak->m--)
	{
		pak->m = 7;
		pak->k = *pak->src++;
	}

	if (_bittest(&pak->k, pak->m))
	{
		r = pak->tlen++;
		pak->dic[0][r - 256] = NR2_MakeDictionary(pak);
		pak->dic[1][r - 256] = NR2_MakeDictionary(pak);
	}
	else
	{
		pak->k = (pak->k << 8) + *pak->src++;
		r = (pak->k >> pak->m) & 255;
	}
	return r;
}

void NR2_MakeHintTable(
	UNPACKER *pak)
{
	DWORD i, j, n, skip;

	for (i = 0; i < (1 << NR2_DWHINTBITS);)
	{
		n = 256;
		j = NR2_DWHINTBITS;
		do {
			j--;
			n = pak->dic[(i >> j) & 1][n - 256];
			if (n <= 255)
				break;
		} while (j);

		skip = i | ((1 << j) - 1);
		do {
			pak->hint[i] = n;
			pak->bits[i] = j;
		} while (i++ < skip);
	}
}

void __fastcall NR2_Uncompress(
	DW_PACDATA *data,
	BYTE *buf)
{
	BYTE *dst, *dst_max;
	const BYTE *src;
	DWORD i, n, hint;
	static UNPACKER pak[1];

	dst = (BYTE *)buf;
	src = (BYTE *)data + data->hdr_offset;
	for (i = 0; i < data->pack_cnt; ++i)
	{
		pak->m = 0;
		pak->k = 0;
		pak->tlen = 256;
		pak->src = src + data->info[i].data_offset;
		n = NR2_MakeDictionary(pak);
		if (n <= 255)
		{
			__stosb(dst, n, data->info[i].unpack_size);
			dst += data->info[i].unpack_size;
			continue;
		}

		NR2_MakeHintTable(pak);

		if ((size_t)pak->src & 1)
		{
			pak->k = (pak->k << 8) + *pak->src++;
			pak->m += 8;
		}

		dst_max = dst + data->info[i].unpack_size;
		for (; dst < dst_max;)
		{
			if (pak->m < NR2_DWHINTBITS)
			{
				pak->k <<= 16;
				pak->m += 16;
				pak->k += _byteswap_ushort(*(WORD *)pak->src);
				pak->src += 2;
			}

			pak->m -= NR2_DWHINTBITS;
			hint = (pak->k >> pak->m) & ((1 << NR2_DWHINTBITS) - 1);
			pak->m += pak->bits[hint];
			n = pak->hint[hint];
			for (; n > 255; n = pak->dic[(pak->k >> pak->m) & 1][n - 256])
			{
				if (!pak->m--)
				{
					pak->m = 15;
					pak->k = _byteswap_ushort(*(WORD *)pak->src);
					pak->src += 2;
				}
			}
			*dst++ = (BYTE)n;
		}
	}
}
#endif