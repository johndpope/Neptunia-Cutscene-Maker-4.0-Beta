Kitserver v1.2 for Neptunia Re;Birth2

kitserver.exe is the body. You need to start the game using this file.
kitserver.dll is required. Please put in the same location as the kitserver.exe.
kitserver.txt If you want to dump text shown on screen during the game, please put in the same location as the kitserver.exe.
kitserver.ini Options file, put in the same folder as kitserver.exe

How to use
- Put kitserver.exe, kitserver.dll, kitserver.txt and kitserver.ini in  "\SteamApps\common\Neptunia Re;Birth2\" folder. 
- Start the game using kitserver.exe

Changelog
New: Add the log output function (please refer to the ini file for details)
Fix: If you change the name to NeptuniaReBirth2.exe the kitserver.exe, fix the problem DLL fall
Fix: Kitserver an error message is output modified to be seen to be derived from Kitserver (uhh what)

Kitserver.exe does not matter if you change the file name. kitserver.dll, kitserver.txt,
Do not change the name for kitserver.ini.
Kitserver.exe will not be changed in the future. If the update came out, kitserver.dll, kitserver.txt,
If you overwrite the kitserver.ini is OK.