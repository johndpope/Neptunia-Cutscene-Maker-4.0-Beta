nr2_strtool v1.1

This is a tool to edit / insert text from a text resource files of Re;Birth2.
The text resources has the following format:
- cl3: subtitles
- gstr: system string
- gbin: system string

Each file is located in the following location.
GAME00000.pac -.> Event / script / * cl3
GAME00001.pac -.> Event / script / * cl3
SYSTEM00000.pac -> database / * gstr; * gbin

Drag and drop the text resource file to nr2_strtool.
Edit resulting text file in notepad.
Drag and drop to nr2_strtool the edited text file again.